# PDF Generation — Public Rail

This folder focuses on generating PDFs for **public-safe** documentation.

We assume you have `pandoc` installed. Example commands (run from repo root):

```bash
# Public meta whitepaper
pandoc public/docs/meta_whitepaper_public.md -o pdf/meta_whitepaper_public.pdf

# Public summary
pandoc public/docs/public_summary.md -o pdf/public_summary.pdf
```

You can extend this list as you add more public docs.