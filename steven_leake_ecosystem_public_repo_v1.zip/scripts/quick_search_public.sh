#!/usr/bin/env bash
# quick_search_public.sh — helper for grepping across the public rail.
# Usage: ./quick_search_public.sh Sophia

TERM="$1"

if [ -z "$TERM" ]; then
  echo "Usage: $0 <term>"
  exit 1
fi

echo "=== PUBLIC RAIL ==="
python public/search/search_bundle.py "$TERM" 2>/dev/null || true