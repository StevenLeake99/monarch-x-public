# Steven Leake Ecosystem — Public Repo (Monarch X • Sophia • Web4)

Version: v1.0.0 (Public Rail)  
Generated: 2025-11-16T01:09:01.400345Z

This repository is a **public-safe subset** of the Steven Leake / Monarch Sovereign
Systems ecosystem. It contains only the **public rail**:

- `public/`   — Public-safe docs, schemas, and code stubs.
- `indexes/`  — Public knowledge index.
- `docs-site/` — Static public documentation site.
- `scripts/`  — Helper script for public search.
- `pdf/`      — PDF generation scaffold for public docs.

No internal scaffolding, private keys, proprietary SoBinLex symbol tables,
or deep SENTIUM datasets are included here.

## Quick Start

### View the Docs Site

From the repo root:

```bash
python -m http.server 8080
# then open http://localhost:8080/docs-site/index.html
```

Or simply open `docs-site/index.html` in your browser.

### Search the Public Rail

```bash
python public/search/search_bundle.py Sophia
./scripts/quick_search_public.sh Monarch
```

### Generate PDFs

```bash
pandoc public/docs/meta_whitepaper_public.md -o pdf/meta_whitepaper_public.pdf
pandoc public/docs/public_summary.md -o pdf/public_summary.pdf
```

## License

See `LICENSE` for the Monarch Sovereign Systems reference license scaffold.