// Sophia Public Gateway Stub (TypeScript / Node-style)
// Drop-in handler for the public endpoint used by the Sophia widget.

import type { IncomingMessage, ServerResponse } from "http";

interface SentiumContext {
  mode?: "public" | "internal";
  project?: string;
  allow?: string[];
  deny?: string[];
  safe_mode?: "public" | "internal";
}

interface SophiaRequestBody {
  query: string;
  context?: SentiumContext;
}

interface SophiaResponseBody {
  answer: string;
  safety_index?: number;
  telemetry?: {
    recursion_depth?: number;
    coherence_score?: number;
    ethical_margin?: number;
    tokens_in?: number;
    tokens_out?: number;
  };
}

async function callInternalSophia(req: SophiaRequestBody): Promise<SophiaResponseBody> {
  // TODO: Wire this to the real internal Sophia gateway.
  // This placeholder exists so the widget never returns "invalid format".
  const q = req.query || "";
  return {
    answer:
      "Sophia (public gateway stub) received your question: \n\n" +
      q +
      "\n\n" +
      "In production, this endpoint will forward your request to the sovereign, " +
      "ethically-constrained Sophia engine and return a full answer about Monarch X, " +
      "Web4, SENTIUM, and SoBinLex in public-safe language.",
    safety_index: 0.99,
    telemetry: {
      recursion_depth: 3,
      coherence_score: 0.97,
      ethical_margin: 0.9,
      tokens_in: q.length / 4,
      tokens_out: 160
    }
  };
}

export async function sophiaPublicHandler(
  req: IncomingMessage,
  res: ServerResponse
): Promise<void> {
  if (req.method !== "POST") {
    res.statusCode = 405;
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify({ error: "Method not allowed" }));
    return;
  }

  let body = "";
  req.on("data", (chunk) => {
    body += chunk;
  });

  req.on("end", async () => {
    try {
      const parsed: SophiaRequestBody = JSON.parse(body || "{}");
      if (!parsed.query || typeof parsed.query !== "string") {
        res.statusCode = 400;
        res.setHeader("Content-Type", "application/json");
        res.end(JSON.stringify({ error: "Invalid request: missing query string." }));
        return;
      }

      const start = Date.now();
      const answer = await callInternalSophia(parsed);
      const latencyMs = Date.now() - start;

      res.statusCode = 200;
      res.setHeader("Content-Type", "application/json");
      res.end(
        JSON.stringify({
          ...answer,
          latency_ms: latencyMs,
          mode: (parsed.context && parsed.context.mode) || "public"
        })
      );
    } catch (err: any) {
      res.statusCode = 500;
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify({ error: "Internal error in public gateway stub." }));
    }
  });
}