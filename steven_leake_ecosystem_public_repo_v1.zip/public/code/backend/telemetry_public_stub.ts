// Telemetry Service Stub (Public-Facing Aggregation)
//
// In production, you may mirror this data to a transparency page
// without exposing user-identifying details.

export interface TelemetryRecord {
  id: string;
  timestamp: string;
  source: "widget" | "api";
  prompt_chars: number;
  response_chars: number;
  latency_ms: number | null;
  ok: boolean;
  safety_index?: number;
}

const inMemoryStore: TelemetryRecord[] = [];

export function recordTelemetry(rec: TelemetryRecord): void {
  inMemoryStore.push(rec);
}

export function queryTelemetry(limit = 100): TelemetryRecord[] {
  return inMemoryStore.slice(-limit).reverse();
}