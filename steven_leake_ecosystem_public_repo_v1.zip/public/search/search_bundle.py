"""Simple local text search across this rail (public or internal).

Usage:
    python search_bundle.py "Sophia"

This script walks the current directory, searches text-like files, and prints matches.
"""

import os
import sys

TEXT_EXT = (".md", ".txt", ".ts", ".sol", ".json", ".jsonld")

def is_text_file(path: str) -> bool:
    return path.endswith(TEXT_EXT)

def main():
    if len(sys.argv) < 2:
        print("Please provide a search term, e.g. `python search_bundle.py Sophia`")
        return

    term = sys.argv[1]
    root = os.path.dirname(os.path.abspath(__file__))
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            path = os.path.join(dirpath, fn)
            if not is_text_file(path):
                continue
            try:
                with open(path, "r", encoding="utf-8") as f:
                    for i, line in enumerate(f, start=1):
                        if term.lower() in line.lower():
                            rel = os.path.relpath(path, root)
                            print(f"{rel}:{i}: {line.rstrip()}")
            except Exception as e:
                print(f"Error reading {path}: {e}", file=sys.stderr)

if __name__ == "__main__":
    main()