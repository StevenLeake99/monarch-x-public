# SoBinLex — Public-Safe Structural Overview

- Symbol set Σ: size 1024 (not listed here).
- Each symbol has:
  - Emotional weight (not published here).
  - Narrative role tag (anchor, bridge, mirror, veil, key, etc.).

Public interface expectations:

- encode_sobinlex(binary: bytes) -> list[int]
- decode_sobinlex(symbol_ids: list[int]) -> bytes

Implementation details and symbol tables are internal and **not** part of this
public schema.